@echo off
setlocal EnableExtensions

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found. Install JDK 25 and reopen this terminal.
  exit /b 1
)

java -version 2>&1 | findstr /C:"25." >nul
if errorlevel 1 (
  echo ERROR: Minecraft 26.1 mod development requires Java 25.
  echo Install JDK 25, set JAVA_HOME, and make sure java -version reports 25.
  exit /b 1
)

where gradle >nul 2>nul
if not errorlevel 1 (
  call gradle build
  exit /b %errorlevel%
)

set "TOOLS_DIR=%CD%\.build-tools"
set "GRADLE_HOME=%TOOLS_DIR%\gradle-9.4.1"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
  echo Downloading Gradle 9.4.1 from the official Gradle distribution host...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-9.4.1-bin.zip' -OutFile '.build-tools\gradle-9.4.1-bin.zip'; Expand-Archive -Force '.build-tools\gradle-9.4.1-bin.zip' '.build-tools'"
  if errorlevel 1 (
    echo ERROR: Could not download Gradle. Install Gradle 9.4.1 or check your internet connection.
    exit /b 1
  )
)

call "%GRADLE_HOME%\bin\gradle.bat" build
exit /b %errorlevel%
