package dev.dogoverlord;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny persistent client config; no server files are touched. */
final class DogOverlordConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("dog-overlord.properties");
    private static final int MIN_PACK_SIZE = 1;
    private static final int MAX_PACK_SIZE = 100;
    private static int maxPackSize = 20;

    private DogOverlordConfig() {}

    static void load() {
        Properties properties = new Properties();
        if (Files.isRegularFile(FILE)) {
            try (InputStream input = Files.newInputStream(FILE)) {
                properties.load(input);
                maxPackSize = clamp(parseInt(properties.getProperty("maxPackSize"), 20));
            } catch (IOException exception) {
                System.err.println("[DOG OVERLORD] Could not read config: " + exception.getMessage());
            }
        }
        save();
    }

    static int getMaxPackSize() {
        return maxPackSize;
    }

    static void setMaxPackSize(int value) {
        maxPackSize = clamp(value);
        save();
    }

    private static int parseInt(String text, int fallback) {
        if (text == null) return fallback;
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static int clamp(int value) {
        return Math.max(MIN_PACK_SIZE, Math.min(MAX_PACK_SIZE, value));
    }

    private static void save() {
        Properties properties = new Properties();
        properties.setProperty("maxPackSize", Integer.toString(maxPackSize));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream output = Files.newOutputStream(FILE)) {
                properties.store(output, "DOG OVERLORD client settings");
            }
        } catch (IOException exception) {
            System.err.println("[DOG OVERLORD] Could not save config: " + exception.getMessage());
        }
    }
}
