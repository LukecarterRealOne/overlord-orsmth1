#!/usr/bin/env bash
set -euo pipefail

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java was not found. Install JDK 25 first." >&2
  exit 1
fi
if ! java -version 2>&1 | grep -q '25\.'; then
  echo "ERROR: Minecraft 26.1 mod development requires Java 25." >&2
  echo "Install JDK 25 and ensure java -version reports 25." >&2
  exit 1
fi

if command -v gradle >/dev/null 2>&1; then
  gradle build
  exit 0
fi

TOOLS_DIR="$PWD/.build-tools"
GRADLE_HOME="$TOOLS_DIR/gradle-9.4.1"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  mkdir -p "$TOOLS_DIR"
  echo "Downloading Gradle 9.4.1 from the official Gradle distribution host..."
  curl -fL 'https://services.gradle.org/distributions/gradle-9.4.1-bin.zip' -o "$TOOLS_DIR/gradle-9.4.1-bin.zip"
  unzip -oq "$TOOLS_DIR/gradle-9.4.1-bin.zip" -d "$TOOLS_DIR"
fi
"$GRADLE_HOME/bin/gradle" build
