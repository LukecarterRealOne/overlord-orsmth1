package dev.dogoverlord;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * DOG OVERLORD is a client-side companion toolkit. Normal taming, name-tag, and
 * owner interactions are sent to the game/server. The recall action sends a vanilla
 * /tp command scoped to the local player's owner UUID and therefore needs command
 * permission; it cannot bypass server authority.
 */
public final class DogOverlordClient implements ClientModInitializer {
    public static final String MOD_ID = "dogoverlord";

    private static final double AUTO_TAME_RANGE = 6.0;
    private static final double PACK_COMMAND_RANGE = 6.0;
    private static final double PACK_COUNT_RANGE = 96.0;
    private static final int AUTO_TAME_INTERVAL_TICKS = 12;
    private static final int PACK_STEP = 5;

    private static KeyMapping openMenuKey;
    private static KeyMapping toggleAutoTameKey;
    private static KeyMapping packSitKey;
    private static KeyMapping packFollowKey;
    private static KeyMapping recallPackKey;
    private static KeyMapping nameNearestKey;

    private static boolean autoTameEnabled = false;
    private static int autoTameCooldown = 0;
    private static boolean warnedAboutBones = false;

    @Override
    public void onInitializeClient() {
        DogOverlordConfig.load();
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "controls")
        );

        openMenuKey = registerKey("key.dogoverlord.open_menu", InputConstants.KEY_G, category);
        toggleAutoTameKey = registerKey("key.dogoverlord.toggle_auto_tame", InputConstants.KEY_R, category);
        packSitKey = registerKey("key.dogoverlord.pack_sit", InputConstants.KEY_H, category);
        packFollowKey = registerKey("key.dogoverlord.pack_follow", InputConstants.KEY_J, category);
        recallPackKey = registerKey("key.dogoverlord.recall_pack", InputConstants.KEY_P, category);
        nameNearestKey = registerKey("key.dogoverlord.name_nearest", InputConstants.KEY_N, category);

        ClientTickEvents.END_CLIENT_TICK.register(DogOverlordClient::onClientTick);
    }

    private static KeyMapping registerKey(String translationKey, int keyCode, KeyMapping.Category category) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(
                translationKey,
                InputConstants.Type.KEYSYM,
                keyCode,
                category
        ));
    }

    private static void onClientTick(Minecraft client) {
        while (openMenuKey.consumeClick()) {
            if (client.player != null) client.setScreen(new DogOverlordScreen());
        }
        while (toggleAutoTameKey.consumeClick()) {
            toggleAutoTame();
            tell(client, "Auto-tame " + (autoTameEnabled ? "ENABLED" : "DISABLED") + ". Hold bones in either hand.");
        }
        while (packSitKey.consumeClick()) commandPack(client, true);
        while (packFollowKey.consumeClick()) commandPack(client, false);
        while (recallPackKey.consumeClick()) recallPack(client);
        while (nameNearestKey.consumeClick()) nameNearestOwnedWolf(client);

        if (!autoTameEnabled || client.player == null || client.level == null || client.gameMode == null) return;
        // Let TAME ALL keep working with the control panel open, but do not automate while
        // other screens (inventory, chat, etc.) are active.
        if (client.screen != null && !(client.screen instanceof DogOverlordScreen)) return;
        if (autoTameCooldown > 0) {
            autoTameCooldown--;
            return;
        }

        InteractionHand boneHand = getBoneHand(client);
        if (boneHand == null) {
            if (!warnedAboutBones) {
                tell(client, "Auto-tame is on, but no bones are in either hand.");
                warnedAboutBones = true;
            }
            return;
        }
        warnedAboutBones = false;

        int ownedCount = getOwnedWolfCount(client);
        if (ownedCount >= DogOverlordConfig.getMaxPackSize()) {
            autoTameEnabled = false;
            autoTameCooldown = 0;
            tell(client, "PACK LIMIT REACHED: " + ownedCount + "/" + DogOverlordConfig.getMaxPackSize() + ". Auto-tame stopped.");
            return;
        }

        var player = client.player;
        AABB searchBox = boxAround(player.getX(), player.getY(), player.getZ(), AUTO_TAME_RANGE);
        List<Wolf> untamedWolves = client.level.getEntitiesOfClass(
                Wolf.class,
                searchBox,
                wolf -> wolf.isAlive() && !wolf.isTame()
                        && wolf.distanceToSqr(player) <= AUTO_TAME_RANGE * AUTO_TAME_RANGE
        );
        Wolf target = untamedWolves.stream()
                .min(Comparator.comparingDouble((Wolf wolf) -> wolf.distanceToSqr(player)))
                .orElse(null);

        if (target == null) {
            // Avoid scanning the nearby area on every client tick when there is no wolf.
            autoTameCooldown = 6;
            return;
        }

        // Vanilla interaction only: normal bone use, RNG, consumption and server checks apply.
        client.gameMode.interact(player, target, new EntityHitResult(target), boneHand);
        autoTameCooldown = AUTO_TAME_INTERVAL_TICKS;
    }

    public static boolean isAutoTameEnabled() {
        return autoTameEnabled;
    }

    public static int getMaxPackSize() {
        return DogOverlordConfig.getMaxPackSize();
    }

    public static void adjustMaxPackSize(int delta) {
        DogOverlordConfig.setMaxPackSize(DogOverlordConfig.getMaxPackSize() + delta);
    }

    public static void toggleAutoTame() {
        autoTameEnabled = !autoTameEnabled;
        autoTameCooldown = 0;
        warnedAboutBones = false;
    }

    public static void setAutoTameEnabled(boolean enabled) {
        autoTameEnabled = enabled;
        autoTameCooldown = 0;
        warnedAboutBones = false;
    }

    /** Starts continuous tame attempts and stops at the configured pack limit. */
    public static void startTameAll(Minecraft client) {
        if (client.player == null || client.level == null) return;
        if (getBoneHand(client) == null) {
            tell(client, "TAME ALL needs bones in your main hand or offhand.");
            return;
        }
        int count = getOwnedWolfCount(client);
        if (count >= getMaxPackSize()) {
            tell(client, "Your pack is already at its limit: " + count + "/" + getMaxPackSize() + ".");
            return;
        }
        setAutoTameEnabled(true);
        tell(client, "TAME ALL started. Stay near wild wolves; stops at pack limit " + getMaxPackSize() + ".");
    }

    public static void commandPackFromMenu(boolean makeSit) {
        commandPack(Minecraft.getInstance(), makeSit);
    }

    public static int getOwnedWolfCount(Minecraft client) {
        if (client.player == null || client.level == null) return 0;
        var player = client.player;
        AABB countBox = boxAround(player.getX(), player.getY(), player.getZ(), PACK_COUNT_RANGE);
        return client.level.getEntitiesOfClass(
                Wolf.class,
                countBox,
                wolf -> wolf.isAlive() && wolf.isTame() && wolf.isOwnedBy(player)
                        && wolf.distanceToSqr(player) <= PACK_COUNT_RANGE * PACK_COUNT_RANGE
        ).size();
    }

    private static void commandPack(Minecraft client, boolean makeSit) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        var player = client.player;
        if (!player.getItemInHand(InteractionHand.MAIN_HAND).isEmpty()) {
            tell(client, "Put your main hand away before issuing pack orders, to avoid using the held item.");
            return;
        }

        AABB searchBox = boxAround(player.getX(), player.getY(), player.getZ(), PACK_COMMAND_RANGE);
        List<Wolf> ownedWolves = client.level.getEntitiesOfClass(
                Wolf.class,
                searchBox,
                wolf -> wolf.isAlive() && wolf.isTame() && wolf.isOwnedBy(player)
                        && wolf.distanceToSqr(player) <= PACK_COMMAND_RANGE * PACK_COMMAND_RANGE
        );

        int ordersSent = 0;
        for (Wolf wolf : ownedWolves) {
            if (wolf.isOrderedToSit() == makeSit) continue;
            // Vanilla's empty-hand owner interaction changes sitting/following state.
            client.gameMode.interact(player, wolf, new EntityHitResult(wolf), InteractionHand.MAIN_HAND);
            ordersSent++;
        }

        if (ownedWolves.isEmpty()) {
            tell(client, "No owned wolves found within " + (int) PACK_COMMAND_RANGE + " blocks.");
        } else {
            tell(client, (makeSit ? "SIT" : "FOLLOW") + " order sent to " + ordersSent + " wolf(s) nearby.");
        }
    }

    /**
     * Uses the already-renamed vanilla name tag on the nearest owned wolf. The chosen
     * name must be written onto the name tag at an anvil; server-side naming stays vanilla.
     */
    public static void nameNearestOwnedWolf(Minecraft client) {
        if (client.player == null || client.level == null || client.gameMode == null) return;
        InteractionHand hand = getRenamedNameTagHand(client);
        if (hand == null) {
            tell(client, "Rename a Name Tag in an anvil first, then hold it and press N.");
            return;
        }

        var player = client.player;
        AABB searchBox = boxAround(player.getX(), player.getY(), player.getZ(), PACK_COMMAND_RANGE);
        Wolf target = client.level.getEntitiesOfClass(
                        Wolf.class,
                        searchBox,
                        wolf -> wolf.isAlive() && wolf.isTame() && wolf.isOwnedBy(player)
                                && wolf.distanceToSqr(player) <= PACK_COMMAND_RANGE * PACK_COMMAND_RANGE
                ).stream()
                .min(Comparator.comparingDouble(wolf -> wolf.distanceToSqr(player)))
                .orElse(null);

        if (target == null) {
            tell(client, "No owned wolf is close enough to name.");
            return;
        }
        client.gameMode.interact(player, target, new EntityHitResult(target), hand);
        tell(client, "Name-tag interaction sent to your nearest wolf. Vanilla rules decide whether it applies.");
    }

    private static InteractionHand getRenamedNameTagHand(Minecraft client) {
        ItemStack main = client.player.getItemInHand(InteractionHand.MAIN_HAND);
        if (main.is(Items.NAME_TAG) && main.has(DataComponents.CUSTOM_NAME)) return InteractionHand.MAIN_HAND;
        ItemStack off = client.player.getItemInHand(InteractionHand.OFF_HAND);
        if (off.is(Items.NAME_TAG) && off.has(DataComponents.CUSTOM_NAME)) return InteractionHand.OFF_HAND;
        return null;
    }

    /**
     * Uses a vanilla /tp selector constrained to this player's Owner UUID. The server
     * must permit commands (single-player cheats or operator permission on a server).
     */
    public static void recallPack(Minecraft client) {
        if (client.player == null || client.player.connection == null) {
            tell(client, "You need to be in a world to recall your pack.");
            return;
        }
        UUID uuid = client.player.getUUID();
        long most = uuid.getMostSignificantBits();
        long least = uuid.getLeastSignificantBits();
        int a = (int) (most >>> 32);
        int b = (int) most;
        int c = (int) (least >>> 32);
        int d = (int) least;
        String ownerNbt = "[I;" + a + "," + b + "," + c + "," + d + "]";
        String command = "tp @e[type=minecraft:wolf,nbt={Owner:" + ownerNbt + "}] @s";
        client.player.connection.sendCommand(command);
        tell(client, "Recall command sent for wolves owned by you. Requires cheats/operator permission; check the server reply.");
    }

    private static InteractionHand getBoneHand(Minecraft client) {
        if (client.player.getItemInHand(InteractionHand.MAIN_HAND).is(Items.BONE)) return InteractionHand.MAIN_HAND;
        if (client.player.getItemInHand(InteractionHand.OFF_HAND).is(Items.BONE)) return InteractionHand.OFF_HAND;
        return null;
    }

    private static AABB boxAround(double x, double y, double z, double radius) {
        return new AABB(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);
    }

    private static void tell(Minecraft client, String message) {
        if (client.player != null) client.player.sendSystemMessage(Component.literal("[DOG OVERLORD] " + message));
    }
}
